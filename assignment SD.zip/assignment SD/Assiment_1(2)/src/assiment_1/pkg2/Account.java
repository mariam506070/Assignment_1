/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assiment_1.pkg2;

import java.util.Date;


public class Account {
    
    int id;
    private static double balance; 
    private double annualInterestRate; 
    private Date //<editor-fold defaultstate="collapsed" desc="comment">
            dateCreated
//</editor-fold>
; 

    
    Account () {
    id = 0;
    balance = 0.0;
    annualInterestRate = 0.0;
}
    
  Account(int newId, double newBalance) 
  {
    id = newId;
    balance = newBalance;
  }  
    
  Account(int newId, double newBalance, double newAnnualInterestRate) 
  {
    id = newId;
    balance = newBalance;
    annualInterestRate = newAnnualInterestRate;
  }
  
  public int getId() 
  {
    return id;
  }
  
public double getBalance() 
{
    return balance;
}

public double getAnnualInterestRate() 
{
    return annualInterestRate;
}

public void setId(int newId)
{
    id = newId;
}

public void setBalance(double newBalance) 
{
    balance = newBalance;
}

public void setAnnualInterestRate(double newAnnualInterestRate)
{
    annualInterestRate = newAnnualInterestRate;
}

   
    public void setDateCreated(Date newDateCreated)
{
    dateCreated = newDateCreated;
}


double getMonthlyInterestRate() 
{
    return annualInterestRate/12;
}


 public double withdraw(double amount) 
{
    return balance -= amount;
}   


 public double  deposit(double amount)
{
    return balance += amount;   
}

}

