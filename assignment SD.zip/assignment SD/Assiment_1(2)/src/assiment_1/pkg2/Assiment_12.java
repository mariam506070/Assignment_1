/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assiment_1.pkg2;
/**
 *
 * @author PC
 */
public class Assiment_12 {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Account acc1 = new Account(1122, 20000, .045);
        
         acc1.withdraw(2500);
         acc1.deposit(3000);

System.out.println("Account ID:" + acc1.id);
System.out.println("Balance:" + acc1.getBalance());
System.out.println("Interest Rate:" + acc1.getAnnualInterestRate());
System.out.println("Balance after withdraw of 2500:" +       acc1.getAnnualInterestRate());
System.out.println("Balance after deposit of 3000:" + acc1.getAnnualInterestRate());
System.out.println("Monthly Interest:" + acc1.id);

   
       
       }

}
    
    

