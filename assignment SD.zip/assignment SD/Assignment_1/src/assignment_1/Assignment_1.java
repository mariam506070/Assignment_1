/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_1;

/**
 *
 * @author PC
 */
public class Assignment_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         TV tv=new TV();

       
        tv.channel=35;
        tv.on=true;
        tv.volumeLevel=5;
        System.out.println(tv.channel );
         System.out.println(tv.volumeLevel );
        System.out.println(tv.on);
         System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        
        
            TV tv1=new TV();
            
            tv1.channel=58;
            tv1.on=false;
            tv1.volumeLevel=4;
             System.out.println(tv1.channel );
        System.out.println( tv1.volumeLevel);
         System.out.println(tv.on );
        
    }
    
}
